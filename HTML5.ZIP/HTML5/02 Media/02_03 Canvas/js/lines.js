	myCanvas_context.moveTo(25,190);
	myCanvas_context.lineTo(40,180);
	myCanvas_context.lineTo(90,150);
	myCanvas_context.lineTo(100,165);
	myCanvas_context.lineTo(130,90);
	myCanvas_context.lineTo(150,100);
	myCanvas_context.lineTo(275,20);
    myCanvas_context.strokeStyle = "#000";
	myCanvas_context.stroke();
