	var chart_bg = new Image();
	chart_bg.src = "_images/chart_bg.gif";
	chart_bg.onload = function() {
	myCanvas_context.drawImage(chart_bg,0,0);
	};