  myCanvas_context.textAlign = "center";
  myCanvas_context.textBaseline = "middle";
  myCanvas_context.fillStyle = "#7F7F7F";
  myCanvas_context.font = "bold 30px sans-serif";
  myCanvas_context.fillText("We're Growing", 155, 100);