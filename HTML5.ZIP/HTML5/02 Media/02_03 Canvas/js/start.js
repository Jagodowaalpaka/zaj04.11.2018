function doCanvas() {
  var my_canvas = document.getElementById("theCanvas");
  var myCanvas_context = my_canvas.getContext("2d");
}
